import EtiquetasHookForm from './components/EtiquetasHookForm'

export default function App(){

    return(
        <>
            <h1>Aula 08</h1>
            <EtiquetasHookForm/>
        </>
    )
}